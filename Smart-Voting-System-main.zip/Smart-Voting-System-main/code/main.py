from flask import Flask, render_template, url_for, request, session, flash, redirect
from flask_mail import *
from email.mime.multipart import MIMEMultipart
import smtplib
import pymysql
import pandas as pd
import numpy as np
import os
import cv2
from PIL import Image
import shutil
import datetime
import time
import requests
from flask import send_file
import io
facedata = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
cascade = cv2.CascadeClassifier(facedata)

mydb=pymysql.connect(host='localhost', user='root', password='8918554736aA@', port=3306, database='smart_voting_system')

sender_address = 'sankitraj807@gmail.com'  # Your Gmail
sender_pass = 'zmka bdbb oukp llww'      # Your new app password (NO spaces if it throws an error)
app=Flask(__name__)
app.config['SECRET_KEY']='ajsihh98rw3fyes8o3e9ey3w5dc'

app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = sender_address
app.config['MAIL_PASSWORD'] = sender_pass


@app.before_request
def initialize():
    if 'initialized' not in session:
        session['IsAdmin'] = False
        session['User'] = None
        session['initialized'] = True


@app.route('/')
@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/admin', methods=['POST','GET'])
def admin():
    if request.method=='POST':
        email = request.form['email']
        password = request.form['password']
        if (email=='admin@voting.com') and (password=='admin'):
            session['IsAdmin']=True
            session['User']='admin'
            flash('Admin login successful','success')
    return render_template('admin.html', admin=session['IsAdmin'])

# =========================
# VIEW ALL VOTERS
# =========================
import os

@app.route('/view_voters')
def view_voters():
    voters = pd.read_sql_query('SELECT * FROM voters', mydb)
    return render_template('view_voters.html', voters=voters)



@app.route('/download_voters')
def download_voters():
    voters = pd.read_sql_query('SELECT * FROM voters', mydb)

    # Save Excel file to memory (no need to save physically)
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        voters.to_excel(writer, index=False, sheet_name='Voters')

    output.seek(0)

    # Send as download
    return send_file(output,mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',download_name='voters_list.xlsx',as_attachment=True)

@app.route('/elections', methods=['GET', 'POST'])
def elections_dashboard():
    if request.method == 'POST':
        # Creating a new election
        name = request.form.get('election_name') or request.form.get('name')
        description = request.form.get('description', '')
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')

        if not name or not start_date or not end_date:
            flash("All fields are required.", "danger")
            return redirect(url_for('elections_dashboard'))

        try:
            cur = mydb.cursor()
            cur.execute('''INSERT INTO elections (name, description, start_date, end_date, status)
                           VALUES (%s, %s, %s, %s, %s)''',
                        (name, description, start_date, end_date, 'upcoming'))
            mydb.commit()
            cur.close()
            flash(f"Election '{name}' created successfully!", "success")
        except Exception as e:
            flash(f"Error creating election: {str(e)}", "danger")
        return redirect(url_for('elections_dashboard'))

    # GET request — fetch elections and categorize
    try:
        elections = pd.read_sql_query("SELECT * FROM elections ORDER BY start_date DESC", mydb)

        if elections.empty:
            ongoing = upcoming = previous = pd.DataFrame()
        else:
            elections['start_date'] = pd.to_datetime(elections['start_date'])
            elections['end_date'] = pd.to_datetime(elections['end_date'])
            today = pd.Timestamp.now().normalize()

            ongoing = elections[
                (elections['start_date'] <= today) &
                (elections['end_date'] >= today)
            ]

            upcoming = elections[
                (elections['start_date'] > today)
            ]

            previous = elections[
                (elections['end_date'] < today)
            ]

        return render_template("elections_dashboard.html",
                               ongoing=ongoing,
                               upcoming=upcoming,
                               previous=previous)

    except Exception as e:
        flash(f"Error loading elections: {str(e)}", "danger")
        return render_template("elections_dashboard.html",
                               ongoing=pd.DataFrame(),
                               upcoming=pd.DataFrame(),
                               previous=pd.DataFrame())


@app.route('/delete_election/<int:id>', methods=['POST'])
def delete_election(id):
    cur = mydb.cursor()
    cur.execute("DELETE FROM elections WHERE id=%s", (id,))
    mydb.commit()
    cur.close()
    flash("Election deleted successfully.", "info")
    return redirect(url_for('elections_dashboard'))


@app.route('/view_nominees')
def view_nominees():
    nominees = pd.read_sql_query('SELECT * FROM nominee', mydb)
    return render_template('view_nominees.html', nominees=nominees)

@app.route('/download_nominees')
def download_nominees():
    nominees = pd.read_sql_query('SELECT * FROM nominee', mydb)

    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        nominees.to_excel(writer, index=False, sheet_name='Nominees')

    output.seek(0)
    return send_file(output,mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',download_name='nominees_list.xlsx',as_attachment=True)

@app.route('/reset_election')
def reset_election():
    try:
        cur = mydb.cursor()
        cur.execute("DELETE FROM vote")  # Clear all votes
        mydb.commit()
        cur.close()
        flash('All votes have been cleared successfully!', 'success')
    except Exception as e:
        flash(f'Error resetting election: {e}', 'danger')
    return redirect(url_for('admin'))

@app.route('/admin_dashboard')
def admin_dashboard():
    # Fetch statistics from database
    voters_df = pd.read_sql_query('SELECT * FROM voters', mydb)
    nominees_df = pd.read_sql_query('SELECT * FROM nominee', mydb)
    votes_df = pd.read_sql_query('SELECT * FROM vote', mydb)

    total_voters = len(voters_df)
    verified_voters = len(voters_df[voters_df['verified'] == 'yes'])
    total_nominees = len(nominees_df)
    total_votes = len(votes_df)

    voting_percentage = 0
    if total_voters > 0:
        voting_percentage = round((total_votes / total_voters) * 100, 2)

    if voting_percentage >= 70:
        turnout_status = "High Turnout 🔥"
    elif voting_percentage >= 40:
        turnout_status = "Moderate Turnout ✨"
    else:
        turnout_status = "Low Turnout 🚶‍♂️"

    return render_template('admin_dashboard.html',
                           total_voters=total_voters,
                           verified_voters=verified_voters,
                           total_nominees=total_nominees,
                           total_votes=total_votes,
                           voting_percentage=voting_percentage,
                           turnout_status=turnout_status)


# =========================
# DELETE VOTER
# =========================
@app.route('/delete_voter', methods=['GET', 'POST'])
def delete_voter():
    if request.method == 'POST':
        aadhar_id = request.form['aadhar_id']
        sql = "DELETE FROM voters WHERE aadhar_id = %s"
        cur = mydb.cursor()
        cur.execute(sql, (aadhar_id,))
        mydb.commit()
        cur.close()
        flash(f"Deleted Voter with Aadhar ID: {aadhar_id}", 'success')
        return redirect(url_for('delete_voter'))
    return render_template('delete_voter.html')


# =========================
# DELETE NOMINEE
# =========================
@app.route('/delete_nominee', methods=['GET', 'POST'])
def delete_nominee():
    if request.method == 'POST':
        symbol_name = request.form['symbol_name']
        cur = mydb.cursor()
        cur.execute("DELETE FROM nominee WHERE symbol_name = %s", (symbol_name,))
        mydb.commit()
        cur.close()
        flash('Nominee deleted successfully!', 'success')
        return redirect(url_for('delete_nominee'))

    df_nominees = pd.read_sql_query('SELECT * FROM nominee', mydb)
    return render_template('delete_nominee.html', nominees=df_nominees)



# =========================
# RESET VOTES
# =========================
@app.route('/reset_votes', methods=['POST'])
def reset_votes():
    sql = "DELETE FROM vote"
    cur = mydb.cursor()
    cur.execute(sql)
    mydb.commit()
    cur.close()
    flash("All votes have been reset successfully!", 'warning')
    return redirect(url_for('admin'))


# =========================
# ADMIN LOGOUT
# =========================
@app.route('/admin_logout')
def admin_logout():
    session['IsAdmin'] = False
    session['User'] = None
    flash("Logged out successfully!", 'info')
    return redirect(url_for('home'))


@app.route('/add_nominee', methods=['POST','GET'])
def add_nominee():
    if request.method=='POST':
        member=request.form['member_name']
        party=request.form['party_name']
        logo=request.form['test']
        nominee=pd.read_sql_query('SELECT * FROM nominee', mydb)
        all_members=nominee.member_name.values
        all_parties=nominee.party_name.values
        all_symbols=nominee.symbol_name.values
        if member in all_members:
            flash(r'The member already exists', 'info')
        elif party in all_parties:
            flash(r"The party already exists", 'info')
        elif logo in all_symbols:
            flash(r"The logo is already taken", 'info')
        else:
            sql="INSERT INTO nominee (member_name, party_name, symbol_name) VALUES (%s, %s, %s)"
            cur=mydb.cursor()
            cur.execute(sql, (member, party, logo))
            mydb.commit()
            cur.close()
            flash(r"Successfully registered a new nominee", 'primary')
    return render_template('nominee.html', admin=session['IsAdmin'])

@app.route('/registration', methods=['POST','GET'])
def registration():
    if request.method=='POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        state = request.form['state']
        d_name = request.form['d_name']
        middle_name = request.form['middle_name']
        aadhar_id = request.form['aadhar_id']
        voter_id = request.form['voter_id']
        pno = request.form['pno']
        age = int(request.form['age'])
        email = request.form['email']
        voters=pd.read_sql_query('SELECT * FROM voters', mydb)
        all_aadhar_ids=voters.aadhar_id.values
        all_voter_ids=voters.voter_id.values
        if age >= 18:
            if (aadhar_id in all_aadhar_ids) or (voter_id in all_voter_ids):
                flash(r'Already Registered as a Voter')
            else:
                sql = 'INSERT INTO voters (first_name, middle_name, last_name, aadhar_id, voter_id, email,pno,state,d_name, verified) VALUES (%s,%s,%s, %s, %s, %s, %s, %s, %s, %s)'
                cur=mydb.cursor()
                cur.execute(sql, (first_name, middle_name, last_name, aadhar_id, voter_id, email, pno, state, d_name, 'no'))
                mydb.commit()
                cur.close()
                session['aadhar']=aadhar_id
                session['status']='no'
                session['email']=email
                return redirect(url_for('verify'))
        else:
            flash("if age less than 18 than not eligible for voting","info")
    return render_template('voter_reg.html')

@app.route('/verify', methods=['POST','GET'])
def verify():
    if session['status']=='no':
        if request.method=='POST':
            otp_check=request.form['otp_check']
            if otp_check==session['otp']:
                session['status']='yes'
                sql="UPDATE voters SET verified='%s' WHERE aadhar_id='%s'"%(session['status'], session['aadhar'])
                cur=mydb.cursor()
                cur.execute(sql)
                mydb.commit()
                cur.close()
                flash(r"Email verified successfully",'primary')
                return redirect(url_for('capture_images')) #change it to capture photos
            else:
                flash(r"Wrong OTP. Please try again.","info")
                return redirect(url_for('verify'))
        else:
            #Sending OTP
            message = MIMEMultipart()
            receiver_address = session['email']
            message['From'] = sender_address
            message['To'] = receiver_address
            Otp = str(np.random.randint(100000, 999999))
            session['otp']=Otp
            message.attach(MIMEText(session['otp'], 'plain'))
            abc = smtplib.SMTP('smtp.gmail.com', 587)
            abc.starttls()
            abc.login(sender_address, sender_pass)
            text = message.as_string()
            abc.sendmail(sender_address, receiver_address, text)
            abc.quit()
    else:
        flash(r"Your email is already verified", 'warning')
    return render_template('verify.html')

@app.route('/capture_images', methods=['POST','GET'])
def capture_images():
    if request.method=='POST':
        cam=cv2.VideoCapture(0, cv2.CAP_DSHOW)
        sampleNum = 0
        path_to_store=os.path.join(os.getcwd(),"all_images\\"+session['aadhar'])
        try:
            shutil.rmtree(path_to_store)
        except:
            pass
        os.makedirs(path_to_store, exist_ok=True)
        while (True):
            ret, img = cam.read()
            try:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            except:
                continue
            faces = cascade.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                # incrementing sample number
                sampleNum = sampleNum + 1
                # saving the captured face in the dataset folder TrainingImage
                cv2.imwrite(path_to_store +r'\\'+ str(sampleNum) + ".jpg", gray[y:y + h, x:x + w])
                # display the frame
            else:
                cv2.imshow('frame', img)
                cv2.setWindowProperty('frame', cv2.WND_PROP_TOPMOST, 1)
            # wait for 100 miliseconds
            if cv2.waitKey(100) & 0xFF == ord('q'):
                break
            # break if the sample number is morethan 100
            elif sampleNum >= 200:
                break
        cam.release()
        cv2.destroyAllWindows()
        flash("Registration is successfull","success")
        return redirect(url_for('home'))
    return render_template('capture.html')

from sklearn.preprocessing import LabelEncoder
import pickle
le = LabelEncoder()

def getImagesAndLabels(path):
    folderPaths = [os.path.join(path, f) for f in os.listdir(path)]
    faces = []
    Ids = []
    global le
    for folder in folderPaths:
        imagePaths = [os.path.join(folder, f) for f in os.listdir(folder)]
        aadhar_id = folder.split("\\")[1]
        for imagePath in imagePaths:
            # loading the image and converting it to gray scale
            pilImage = Image.open(imagePath).convert('L')
            # Now we are converting the PIL image into numpy array
            imageNp = np.array(pilImage, 'uint8')
            # extract the face from the training image sample
            faces.append(imageNp)
            Ids.append(aadhar_id)
            # Ids.append(int(aadhar_id))
    Ids_new=le.fit_transform(Ids).tolist()
    output = open('encoder.pkl', 'wb')
    pickle.dump(le, output)
    output.close()
    return faces, Ids_new

@app.route('/train', methods=['POST','GET'])
def train():
    if request.method=='POST':
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        faces, Id = getImagesAndLabels(r"all_images")
        print(Id)
        print(len(Id))
        recognizer.train(faces, np.array(Id))
        recognizer.save("Trained.yml")
        flash(r"Model Trained Successfully", 'Primary')
        return redirect(url_for('home'))
    return render_template('train.html')
@app.route('/update')
def update():
    return render_template('update.html')
@app.route('/updateback', methods=['POST','GET'])
def updateback():
    if request.method=='POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        middle_name = request.form['middle_name']
        aadhar_id = request.form['aadhar_id']
        voter_id = request.form['voter_id']
        email = request.form['email']
        pno = request.form['pno']
        age = int(request.form['age'])
        voters=pd.read_sql_query('SELECT * FROM voters', mydb)
        all_aadhar_ids=voters.aadhar_id.values
        if age >= 18:
            if (aadhar_id in all_aadhar_ids):
                sql="UPDATE VOTERS SET first_name=%s, middle_name=%s, last_name=%s, voter_id=%s, email=%s,pno=%s, verified=%s where aadhar_id=%s"
                cur=mydb.cursor()
                cur.execute(sql, (first_name, middle_name, last_name, voter_id, email,pno, 'no', aadhar_id))
                mydb.commit()
                cur.close()
                session['aadhar']=aadhar_id
                session['status']='no'
                session['email']=email
                flash(r'Database Updated Successfully','Primary')
                return redirect(url_for('verify'))
            else:
                flash(f"Aadhar: {aadhar_id} doesn't exists in the database for updation", 'warning')
        else:
            flash("age should be 18 or greater than 18 is eligible", "info")
    return render_template('update.html')

@app.route('/voting', methods=['POST','GET'])
def voting():
    if request.method=='POST':
        pkl_file = open('encoder.pkl', 'rb')
        my_le = pickle.load(pkl_file)
        pkl_file.close()
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        recognizer.read("Trained.yml")
        cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        font = cv2.FONT_HERSHEY_SIMPLEX
        flag = 0
        detected_persons = []

        while True:
            ret, im = cam.read()
            flag += 1
            if flag == 200:
                flash(r"Unable to detect person. Contact help desk for manual voting", "info")
                cam.release()
                cv2.destroyAllWindows()
                return render_template('voting.html')

            gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
            faces = cascade.detectMultiScale(gray, 1.2, 5)
            print(faces)
            for (x, y, w, h) in faces:
                Id, conf = recognizer.predict(gray[y:y + h, x:x + w])
                print(f"Predicted Id: {Id}, Confidence: {conf}")

                if conf > 40:  # CONFIDENCE threshold
                    det_aadhar = my_le.inverse_transform([Id])[0]
                    session['select_aadhar'] = det_aadhar
                    cam.release()
                    cv2.destroyAllWindows()
                    return redirect(url_for('select_candidate'))

            cv2.imshow('im', im)
            try:
                cv2.setWindowProperty('im', cv2.WND_PROP_TOPMOST, 1)
            except:
                pass

            if cv2.waitKey(1) == ord('q'):
                break

        cam.release()
        time.sleep(3)  # sleep for 3 seconds

        cv2.destroyAllWindows()
    return render_template('voting.html')

@app.route('/select_candidate', methods=['POST', 'GET'])
def select_candidate():
    # Extract voter's aadhar from session
    aadhar = session.get('select_aadhar')

    # Fetch all nominees
    df_nom = pd.read_sql_query('SELECT * FROM nominee', mydb)
    all_nom = df_nom['symbol_name'].values

    # Check if voter already voted
    votes_df = pd.read_sql_query('SELECT * FROM vote', mydb)
    voted_aadhars = votes_df['aadhar'].values

    if aadhar in voted_aadhars:
        flash("You have already voted.", "warning")
        return redirect(url_for('home'))

    if request.method == 'POST':
        # Capture selected vote (symbol)
        vote = request.form['test']
        session['vote'] = vote

        # Insert vote into database
        sql = "INSERT INTO vote (vote, aadhar) VALUES (%s, %s)"
        cur = mydb.cursor()
        cur.execute(sql, (vote, aadhar))
        mydb.commit()
        cur.close()

        # Fetch voter's details (mobile number and first name)
        voter_info = pd.read_sql_query("SELECT pno, first_name FROM voters WHERE aadhar_id = %s", mydb, params=[aadhar])

        pno = str(voter_info['pno'].iloc[0])
        name = voter_info['first_name'].iloc[0]

        # Generate date and time
        ts = time.time()
        date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
        timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')

        # Prepare SMS
        url = "https://www.fast2sms.com/dev/bulkV2"
        message = f"Hi {name}, your voting was successful at {timeStamp} on {date}. Thank you for participating!"

        data = {
            "route": "q",
            "message": message,
            "language": "english",
            "flash": 0,
            "numbers": pno,
        }

        headers = {
            "authorization": "UwmaiQR5OoA6lSTz93nP0tDxsFEhI7VJrfKkvYjbM2C14Wde8g9lvA2Ghq5VNCjrZ4THWkF1KOwp3Bxd",  # <-- Replace with your actual API key
            "Content-Type": "application/json"
        }

        # Send SMS
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            print("SMS sent successfully:", response.text)
        except Exception as e:
            print("Failed to send SMS:", e)

        flash("Voted Successfully ✅", "primary")
        return redirect(url_for('home'))

    return render_template('select_candidate.html', noms=sorted(all_nom))

@app.route('/voting_res')
def voting_res():
    votes = pd.read_sql_query('SELECT * FROM vote', mydb)
    
    counts = votes['vote'].value_counts().reset_index()
    counts.columns = ['symbol_name', 'vote_count']

    all_imgs = ['1.png', '2.png', '3.jpg', '4.png', '5.png', '6.png']

    all_freqs = [counts[counts['symbol_name'] == i]['vote_count'].values[0] if i in counts['symbol_name'].values else 0 for i in all_imgs]

    df_nom = pd.read_sql_query('SELECT * FROM nominee', mydb)
    all_nom = df_nom['symbol_name'].values

    return render_template('voting_res.html', freq=all_freqs, noms=all_nom)

if __name__=='__main__':
    app.run(debug=True)

